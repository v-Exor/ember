# Laboratory 5 Python kit

Run these commands from the extracted folder:

```powershell
python -m pip install -r python/requirements.txt
python python/lab5_pca.py
```

Close each plot window to continue. The first run downloads LFW. See python/README.md for settings and downloads/ANSWERS.md for all nine written answers. The model exporter is included for reproducing website assets; it is not required to complete the original activity.
